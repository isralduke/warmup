---
title: Private School Website
date: 2019-03-30 00:00:00 Z
excerpt: Website Design and Content Management System set up for a Private School.
images:
- "/assets/projects/website-private-school-designed-isral-duke-1.jpg"
- "/assets/projects/website-private-school-designed-isral-duke-2.jpg"
- "/assets/projects/website-private-school-designed-isral-duke-3.jpg"
project_roles:
- uxdesigner
- graphicdesigner
- frontend
project_type: website
featured: featured
---