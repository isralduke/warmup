---
title: Tiger Signal T-Shirt
date: 2019-03-24 00:00:00 Z
excerpt: The college football team has a fiercely loyal following. This design mixes
  imagery from another fan base.
images:
- /assets/projects/tiger-signal-shirt-designed-isral-duke-back.jpg
- /assets/projects/tiger-signal-shirt-designed-isral-duke-front.jpg
project_roles:
- graphicdesigner
project_type: marketing
---