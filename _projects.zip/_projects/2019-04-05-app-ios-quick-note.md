---
title: iOS Note App
date: 2019-04-05 00:00:00 Z
excerpt: A free note taking and sketch app on the Apple App Store.
images:
  - /assets/projects/app-ui-ios-note-designed-isral-c-duke-1.jpg
  - /assets/projects/app-ui-ios-note-designed-isral-c-duke-2.jpg
  - /assets/projects/app-ui-ios-note-designed-isral-c-duke-3.jpg
project_roles:
- uidesigner
- graphicdesigner
project_type: app
featured: featured
---