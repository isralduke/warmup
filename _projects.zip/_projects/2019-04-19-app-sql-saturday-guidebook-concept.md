---
title: SQL Saturday Guidebook App Concept
date: 2019-04-19 00:00:00 Z
excerpt: A guidebook app concept for SQL Saturday, an annual developer conference,
  designed with Xamarin development in mind.
images:
- "/assets/projects/app-sql-saturday-guidebook-concept-designed-by-isral-duke.jpg"
project_roles:
- uxdesigner
- uidesigner
- graphicdesigner
project_type: app
featured: featured
---