---
title: Karaoke Competition App
date: 2019-03-28 00:00:00 Z
excerpt: A karaoke competition app designed for social events.
images:
- /assets/projects/app-ux-duet-karoake-adobe-creative-jam-winner-michael-alford-isral-duke.jpg
project_roles:
- uxdesigner
- uidesigner
- graphicdesigner
project_type: app
featured: featured
---